<div class="row row-cols-1 row-cols-md-2 g-4">
  <div class="col">
    <div class="mb-3">
      <div class="row g-0">
        <div class="col">
          <div class="text-end">
            <h5 class="card-title">Blood Count</h5>
            <p class="">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
          </div>
        </div>
        <div class="col-md-4 text-center">
          <i class="fas fa-4x pt-2 fa-user-md"></i>
        </div>
      </div> <!-- end of row -->
    </div> <!-- end of card container -->
  </div> <!-- end of column -->
  <div class="col">
    <div class="mb-3">
      <div class="row g-0">
        <div class="col">
          <div class="text-end">
            <h5 class="card-title">Analyzing and Test Samples</h5>
            <p class="">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
          </div>
        </div>
        <div class="col-md-4 text-center">
          <i class="fas fa-4x pt-2 fa-heartbeat"></i>
        </div>
      </div> <!-- end of row -->
    </div> <!-- end of card container -->
  </div> <!-- end of column -->
  <div class="col">
    <div class="mb-3">
      <div class="row g-0">
        <div class="col">
          <div class="text-end">
            <h5 class="card-title">Ensure Accurate Test Results</h5>
            <p class="">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
          </div>
        </div>
        <div class="col-md-4 text-center">
          <i class="fas fa-4x pt-2 fa-user-nurse"></i>
        </div>
      </div> <!-- end of row -->
    </div> <!-- end of card container -->
  </div> <!-- end of column -->
  <div class="col">
    <div class="mb-3">
      <div class="row g-0">
        <div class="col">
          <div class="text-end">
            <h5 class="card-title">Diagnose Disease</h5>
            <p class="">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
          </div>
        </div>
        <div class="col-md-4 text-center">
          <i class="fas fa-4x pt-2 fa-ambulance"></i>
        </div>
      </div> <!-- end of row -->
    </div> <!-- end of card container -->
  </div> <!-- end of column -->
</div>