<?php 
	include("../db.php");
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}
	else{
		$form_id= $_POST['form_id'];
		$consultant_id= $_POST['consultant_id'];


		$sql = "UPDATE form SET consultant_id='$consultant_id', status='Approved' WHERE form_id='$form_id'";
		if ($conn -> query($sql) === TRUE) {
			$response = ["code"=>200];
		}
		else{
			$error = "Error:" . $sql . "<br>" . $conn->error;
			$response = ["code"=>400, "error" => $error];
		}
		echo json_encode($response);
	}

?>