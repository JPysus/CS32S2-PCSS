<script src="https://cdn.jsdelivr.net/npm/js-cookie@3.0.1/dist/js.cookie.min.js"></script>
<script>
	var path = "<?php echo $_SERVER['HTTP_HOST'] == "pcss-cs32s2.000webhostapp.com" ? " " : "pcss";?>"+"/public";
	path = path.trim();
	//logout.php
	Cookies.remove('id',{path:path});
	Cookies.remove('type',{path: path});
	Cookies.remove('name',{path: path});
	window.location.replace("../index.php");
</script>
