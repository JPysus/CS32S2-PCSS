<?php
include("endpoints/db.php");
$message = '';
if(!isset($_COOKIE['count'])){
    $cookie = 0;
    setcookie('count', $cookie, time()+300);
}
if (isset($_POST['login'])) {
	$email = $_POST['email'];
	$sql = "SELECT * FROM consultant WHERE email = '$email'";
	$list = $conn->query($sql);
	$pass = False;
	if ($list->num_rows > 0) {
		$result = $list->fetch_all(MYSQLI_ASSOC);
		foreach ($result as $row) {
			if (hash('haval256,3', $_POST['password']) == $row['password']) {
				$datetime1 = strtotime($row["password_date_created"]);
				$datetime2 = strtotime(date('Y-m-d', time()));
				$days = ($datetime2-$datetime1)/86400;

				setcookie("id", $row["consultant_id"], time() + 3600);
				setcookie("name", $row["fname"] . " " . $row["lname"], time() + 3600);
				setcookie("type", "consultant", time() + 3600);
				setcookie("passExpiration", $days, time()+3600);
				setcookie('count', "", time()-300);
				$pass=True;
				header("location:dashboard.php");
			} 
			else {
				$message = '<div class="alert alert-danger">Invalid Email or Password</div>';
			}
		}
	} 
	if(!$pass){
	    if(isset($_COOKIE['count'])){
    		$cookies = ++$_COOKIE['count'];
    		setcookie('count', $cookies, time()+300);
    		$message = '<div class="alert alert-danger">Invalid Email or Password</div>';
        	 echo "<script> console.log(\"Final Dawn Counter: ". $_COOKIE['count'] ."\");</script>";
	    }
	}
}
?>
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">
			<?php
				if(!isset($_COOKIE['count'])||$_COOKIE['count']<3){
			?>
				<form action="index.php" method="post">
					<div class="modal-header justify-content-center">
						<a href="index.php">
							<h5 class="brand" id="staticBackdropLabel">Login</h5>
						</a>
					</div>
					<div class="modal-body">
						<div class="container">
							<h4 class="mb-3 fw-bold  text-center">Login to start your session</h4>
							<span><?php echo $message; ?></span>
							<label for="email" class="form-label">Email address</label>
							<div class="input-group flex-nowrap mb-3">
								<input type="email" class="form-control" placeholder="Email" id="email" name="email" value="" required>
								<label class="input-group-text" id="addon-wrapping" for="email"><i class="fas fa-user fa-1x p-2"></i></label>
							</div>
							<label for="password" class="form-label">Password</label>
							<div class="input-group flex-nowrap mb-3">
								<input type="password" class="form-control" placeholder="Password" id="password" name="password" value="" required>
								<label class="input-group-text" id="addon-wrapping" for="password"><i class="fas fa-lock fa-1x p-2"></i></label>
							</div>
						</div>
					</div>
					<div class="modal-footer justify-content-between mx-3 my-2">
						<a href="../public" class="text-decoration-underline fst-italic">Go to website</a>
						<button type="submit" class="btn btnSquare" name="login">Login</button>
					</div>
				</form>
			<?php
				}
				else{;
			?>
				<div id="loginTimeout">
					<div class="modal-header justify-content-center">
						<i class="fa-solid fa-circle-info fa-2x	text-warning"></i>
						Too many mistakes! 
						Answer the captcha to login
					</div>
					<form>
						<div class="modal-body">
								<img id="captcha" src=""/>
								<input type="text" id="captchaText">	
						</div>
						<div class="modal-footer justify-content-between mx-3 my-2">
							<a href="../public" class="text-decoration-underline fst-italic">Go to website</a>
							<input type="submit" class="btn-secondary btnSquare "id="captchaBtn" value="Submit">
						</div>
					</form>
				</div>
				<script>
					console.log("Current Captcha is only a placeholder for now.")
				</script>
			<?php
				}
			?>
		</div>

	</div>
</div>

<script>

// CAPTCHA API
// const settings = {
// 	"async": true,
// 	"crossDomain": true,
// 	"url": "https://simple-text-captcha.p.rapidapi.com/?length=6",
// 	"method": "GET",
// 	"headers": {
// 		"x-rapidapi-host": "simple-text-captcha.p.rapidapi.com",
// 		"x-rapidapi-key": "807e27b763msh32582b37ce10b32p1b3c9fjsn52e832d68eb5"
// 	}
// };

	$.ajax("placeholderCaptcha.json").done(function (response) {
		$("#captcha").attr("src", "data:image/png;base64,"+response["image_base64"]);
		$("form").submit(function(){
			let captchaPass = $("#captchaText").val()==response["correct_answer"];
			console.log("Verify Captcha: " + captchaPass);
			var path = "<?php echo $_SERVER['HTTP_HOST'] == "pcss-cs32s2.000webhostapp.com" ? " " : "pcss";?>"+"/admin";
			path = path.trim();
			if(captchaPass){
				var inFiveMins = new Date(new Date().getTime() - (5 * 60 * 1000));
				Cookies.set('count', 0, {path: path, expires: inFiveMins});
			}
		});
	});
	$(document).ready(function() {
		$("#staticBackdrop").modal('show');
	});
	 // $("form").submit(function(e){
  //       e.preventDefault();
  //   });
</script>
