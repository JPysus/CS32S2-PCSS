<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta content='maximum-scale=1.0, initial-scale=1.0, width=device-width' name='viewport'>

	<title>PCSS</title>

	<?php include 'assets/links.php'; ?>
	
</head>

<body id="bodyContainer">
    <?php 
    		//console.log(\"".hash('haval256,3', 'asdASD123 ')."\");
    echo "<script>
    		console.log(\"".$_SERVER['HTTP_HOST']."\");
    		console.log(\"".$_SERVER['REMOTE_ADDR']."\");
    		console.log(\"".$_SERVER['SERVER_PORT']."\");
    		console.log(\"".$_SERVER['SERVER_ADDR']."\");
    		console.log(\"".$_SERVER['LOCAL_ADDR']."\");
		</script>";
    ?>
	<?php include 'templates/header.php'; ?>

	<?php include 'components/schedule-consultation-modal.php'; ?>
	
	<?php include 'components/medical-records.php'; ?>
	
	<?php include 'components/login.php'; ?>
	
	<div class="position-relative component">
		<?php include 'components/img-carousel.php'; ?>
	</div>

	<div class="content-container">
		<?php include 'components/schedule.php'; ?>
	</div>

	<div class="content-container component" id="services">
		<div class="text-center mb-2 ">
				<h2>Our Services</h2>
		</div>
		<?php include 'components/services-cards.php' ?>
	</div>

	<div class="container component" id="doctors">
		<div class="text-center mb-4 brand ">
				<h2>Meet your Trustworthy Doctors</h2>
		</div>
		<?php include 'components/doctor-cards.php'; ?>
	</div>
	
	<div class="content-container component" id="department">
		<div class="text-center mb-4 brand ">
				<h2>Departments</h2>
		</div>
		<?php include 'components/departments-accordion.php'; ?>
	</div>
	<!--
	<div class="wide-container component">
		<?php //include 'components/testimonies-carousel.php' ?>
	</div>
	-->
	<div class="container" id="contact">
		<?php include 'components/schedule.php'; ?>
	</div>
	
	<?php include 'templates/footer.php'; ?>
<script>

	var path = "<?php echo $_SERVER['HTTP_HOST'] == "pcss-cs32s2.000webhostapp.com" ? " " : "pcss";?>"+"/public";
	path = path.trim();
    var hostdomain = "<?php echo $_SERVER['HTTP_HOST'];?>";
    var hostip = "<?php echo @gethostbyname($_SERVER['HTTP_HOST']);?>";
    const settings = {
    	"async": true,
    	"crossDomain": true,
    	"url": "https://dns-lookup5.p.rapidapi.com/simple?domain="+hostdomain+"&recordType=A",
    	"method": "GET",
    	"headers": {
    		"x-rapidapi-host": "dns-lookup5.p.rapidapi.com",
    		"x-rapidapi-key": "807e27b763msh32582b37ce10b32p1b3c9fjsn52e832d68eb5"
    	}
    };
    
    $.ajax(settings)
    .done(function (response) {
        console.log("Footprinting Tool - DNS Lookup by nslookup.io");
    	console.log(response);
        var apikey = "30BJ7-YJ9F3-IQP65-S33JW";
        var url =
            "https://webresolver.nl/api.php?key="+apikey+"&json&action=portscan&string="+hostdomain;
     	    $.get(url)
     	    .done(function(data){
    			console.log("Scanning Tool - Port Scanner by WebResolver.nl");
    			console.log(data);
    		});
    });
    
    $.get("config/endpoints/viewDnsAPI.php", {actionIndex: 0})
    .done(function(data){
    	console.log("Reverse IP by viewDns.info");
    	console.log("Current Output is from a test.json, as a placeholder. \nThis was done cuz of the API counter limitation");
    	console.log(JSON.parse(data));
    });
</script>
</body>
</html>
