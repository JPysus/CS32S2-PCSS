<?php 
	$servername = "localhost";
	switch($_SERVER['HTTP_HOST']){
		case "pcss-cs32s2.000webhostapp.com":
		$username = "id18436203_root";
		$password = "2c^vIWD-yh~e?t3&";
		$database = "id18436203_pcss";
		break;
		default:
		$username = "root";
		$password = "";
		$database = "pcss";
	}
	// Create connection
	$conn = new mysqli($servername, $username, $password, $database);

?>