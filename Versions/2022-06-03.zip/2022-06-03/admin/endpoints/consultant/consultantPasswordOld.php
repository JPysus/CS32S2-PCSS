<?php 
	//display
	include("../db.php");
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}
	else{
		$consultant_id = $_POST['consultant_id'];
		
		//updates password
		if(isset($_POST['insertOldPassword'])){

			$sql = "SELECT password FROM consultant WHERE consultant_id = '$consultant_id'";
			$result = $conn -> query($sql);
			$password = ($result->fetch_all(MYSQLI_ASSOC))[0]["password"];
			$date = date('Y-m-d', time());

			$sql = "
				INSERT INTO password_old (password_old_id, password_old, password_date_changed, consultant_id) VALUES (NULL,'$password','$date','$consultant_id')
			";
			if ($conn -> query($sql) === TRUE) {
				$response = ["code"=>200];
			}
			else{
				$error = "Error:" . $sql . "<br>" . $conn->error;
				$response = ["code"=>400, "error" => $error];
			}
			echo json_encode($response);
		}

		//checks if input password exists
		else if(isset($_POST['password'])){
			$sql = "
			SELECT password_old, password_date_changed
			FROM password_old
			WHERE consultant_id = '$consultant_id' 
			UNION
			SELECT password, password_date_created
			FROM consultant
			WHERE consultant_id = '$consultant_id' 
			ORDER BY password_date_changed DESC 
			LIMIT 6";
			$result = $conn -> query($sql);
			if ($result->num_rows > 0) {
			    $password = hash('haval256,3', $_POST['password']);//$_POST['password'];
				$result = $result->fetch_all(MYSQLI_ASSOC);
				for($i = 0; $i < count($result); $i++){
					if($result[$i]['password_old'] == $password){
						echo true; //1
						break;
					}
				}
				echo false;//0
			}
			else{
				echo false;//0
			}
		}
		else{
			$error = "Error:" . $sql . "<br>" . $conn->error;
			$response = ["code"=>400, "error" =>$error];
			echo json_encode($response);
		}

			
	}

?>