<!DOCTYPE html>
<html lang="en">

<?php
if (isset($_COOKIE["type"]))
	if ($_COOKIE["type"] == "patient")
		header("location:logout.php");
if (!isset($_COOKIE["id"])) {
	header("location:index.php");
}
include("endpoints/db.php");
$sql = "SELECT consultant_id, fname, lname, email, job FROM consultant";
$result = $conn->query($sql);
$ajaxVar = ["consultant_id", "fname", "lname", "email", "password", "job"];
$placeholder = ["ID", "First Name", "Last Name", "email", "password", "job"];
?>

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="maximum-scale=1.0, width=device-width, initial-scale=1.0">
	<title>PCSS admin</title>

	<?php include 'assets/links.php'; ?>

</head>

<body>
	<div class="" id="pageUsers">
		<?php include 'templates/side-nav.php'; ?>
	</div>
	<div class="content" id="mainContainer">
		<?php include 'templates/header.php'; ?>
		<hr>

		<!-- page content -->
		<div class="container">
			<label class="caption-body">User List</label>

			<!-- myTable -->
			<table class="table table-hover align-middle" id="myTable">
				<thead>
					<tr>
						<?php
						for ($i = 0; $i < count($placeholder); $i++)
							echo '<th class="">', $placeholder[$i], '</th>';
						echo '<th class="">Edit/Delete</td>';
						?>
					</tr>
				</thead>
				<tbody>
					<?php
					while ($row = $result->fetch_assoc()) {
						echo '<tr>';
						for ($i = 0; $i < count($ajaxVar); $i++){
							if($i == 4){
								echo '<td>**********</td>';	
							}
							else echo '<td>', $row[$ajaxVar[$i]], '</td>';
						}
						echo '
						<td>
							<button class="chg btn fas fa-edit px-3 bg-dark" href="#" value="', $row[$ajaxVar[0]], '"></button>
							<button class="del btn fas fa-trash-alt bg-danger" href="#" value="', $row[$ajaxVar[0]], '"></button>
							<button class="upd btn fas fa-check-square bg-success" href="#" value="', $row[$ajaxVar[0]], '"style="display:none"></button>
						</td>
						';
						echo '</tr>';
					}
					include 'modal-add-user.php';
					?>
				</tbody>
			</table><!-- end of myTable-->
		</div>
		<hr>
		<div class="d-flex justify-content-center">

			<button class="btn btnSquare" onclick="modalAddUser()">
				<i class="fas fa-plus"></i>
				Add User
			</button>
		</div>
		<?php include 'templates/bottom-nav.php'; ?>
	</div>
</body>

</html>

<script>
	$(document).ready(function() {
		$('#myTable').dataTable();
	});

	//delete function per Table Row
	$('.del').click(function() {
		$(this).parent().parent().hide();
		deleteRecord($(this).attr("value"));
	});

	//change function per Table Row
	$('.chg').click(function() {
	
		passwordInput = $(this).parent().parent().find('td:eq('+4+')');
		passwordInput.html("<input value=\"\" style=\"max-width: 170px;border:3px solid black\">");

		jobInput = $(this).parent().parent().find('td:eq('+5+')');
		jobInput.html("<input value=\""+jobInput.html()+"\" style=\"max-width: 170px;border:3px solid black\">");
		
		//$(this).parent().parent().find(
		$(this).hide();
		// console.log($(this).parent().parent().find('td:eq(4)').html());
		$(this).parent().find('button:eq(1)').hide();
		$(this).parent().find('button:eq(2)').show();

		index = $(this).parent().find('button:eq(2)').val();
		temp = $(this).parent().parent();

		fname = temp.find('td:eq(1)').html();
		lname = temp.find('td:eq(2)').html();
		var name = [fname, lname];
		console.log(name);
		newPassword = temp.find('td:eq(4)').find('input');
		newPassword.on("input",function(){
			password = $(this).val();
    		var errIndex = -1;
			if(errIndex < 0){
				//checks if the password is 10 letters or more
				if(!pattern.test(password)){
					errIndex = 0;
				}

				//checks if password is against the regex
				else if(password.length < 10){
					errIndex = 1;
				}

				//checks if password is in dictionary
				//3 letter words or less are okay
				else if(errIndex < 0){
					for (let i = 0; i < password.length; i++) {
				        for (let j = i; j <= password.length; j++){
							let word = password.substr(i, j - i);
							if(name.includes(word.toLowerCase())){
								errIndex = 3;
							}
				        	else if(j - i < 3){
				        		continue;
				        	}
							
							else if(dicjson.hasOwnProperty(word.toLowerCase())){
								if(word.length > 3){
								    errMsg[2] = errMsg[2].substr(0,errMsg2Len)+word;
									errIndex = 2;
								}
							}
							if(errIndex >= 0)break;
						}
						if(errIndex >= 0)break;
				    }	
				}
				if(errIndex < 0){
		    		$.post("endpoints/consultant/consultantPasswordOld.php", {consultant_id: index, password: password}).done(function(data){
						if(typeof data == "string" && data == "1"){
						// 	console.log(passwordPolicy);
							errIndex = 4;
				            newPassword.css("border","3px solid #ff0000");
							newPassword.get(0).setCustomValidity(errMsg[errIndex]);
				            newPassword.get(0).reportValidity();
						}
						else{
							newPassword.get(0).setCustomValidity("");
							newPassword.css("border","3px solid #AAFF00");
						}
		    		});
				}
				else{
				    newPassword.css("border","3px solid #ff0000");
					newPassword.get(0).setCustomValidity(errMsg[errIndex]);
				    newPassword.get(0).reportValidity();
				}
			}
		}).focus(function(){
    	   $(this).get(0).reportValidity();
    	});
	});

	//update function per Table Row
	$('.upd').click(function() {
		index = $(this).val();
		temp = $(this).parent().parent();

		fname = temp.find('td:eq(1)').html();
		lname = temp.find('td:eq(2)').html();
		var name = [fname, lname];

		newPassword = temp.find('td:eq(4)').find('input');
        newPassword.css("border","1px solid black");
		password = newPassword.val();

		var errIndex = -1;

			if(errIndex < 0){
				//checks if the password is 10 letters or more
				if(!pattern.test(password)){
					errIndex = 0;
				}

				//checks if password is against the regex
				else if(password.length < 10){
					errIndex = 1;
				}

				//checks if password is in dictionary
				//3 letter words or less are okay
				else if(errIndex < 0){
					for (let i = 0; i < password.length; i++) {
				        for (let j = i; j <= password.length; j++){
							let word = password.substr(i, j - i);
							if(name.includes(word.toLowerCase())){
								errIndex = 3;
							}
				        	else if(j - i < 3){
				        		continue;
				        	}
							
							else if(dicjson.hasOwnProperty(word.toLowerCase())){
								if(word.length > 3){
								    errMsg[2] = errMsg[2].substr(0,errMsg2Len)+word;
									errIndex = 2;
								}
							}
							if(errIndex >= 0)break;
						}
						if(errIndex >= 0)break;
				    }	
				}
				if(errIndex < 0){
					$.post("endpoints/consultant/consultantPasswordOld.php", {consultant_id: index, password: password}).done(function(data){
						if(typeof data == "string" && data == "1"){
						// 	console.log(passwordPolicy);
							errIndex = 4;
				            newPassword.css("border","3px solid red");
							newPassword.get(0).setCustomValidity(errMsg[errIndex]);
				            newPassword.get(0).reportValidity();
						}
						else{
							newPassword.get(0).setCustomValidity("");
							newPassword.css("border","3px solid #AAFF00");
							insertOldPassword(temp);
							updateRecord(temp);
							alert("User Updated");
						}
					});
				}
				else{
				    newPassword.css("border","3px solid red");
					newPassword.get(0).setCustomValidity(errMsg[errIndex]);
				    newPassword.get(0).reportValidity();
				// 			console.log(passwordPolicy);
				}
			}
	});
	//INSERT
	function insertOldPassword(e) {
		$.ajax({
			'url': "endpoints/consultant/consultantPasswordOld.php",
			'type': "POST",
			'data': {
				consultant_id: $(e).find('td:eq(0)').text(),
				insertOldPassword: "true",
			},
			success: function(response) {
				response = JSON.parse(response);
				if (response.code == 200) {
					console.log(response);
				} else if (response.code == 400) {
					console.log(response.error);

				} else {
					console.log(response.code);
				}
			}
		});
	}
	//UPDATE
	function updateRecord(e) {
		$.ajax({
			'url': "endpoints/consultant/consultantUpdate.php",
			'type': "POST",
			'data': {
				<?= $ajaxVar[0] ?>: $(e).find('td:eq(0)').text(),
				<?php
				for ($i = 4; $i < count($ajaxVar); $i++){

					echo $ajaxVar[$i], ': $(e).find(\'td:eq(', $i, ')\').find(\'input\').val(),';
				}
				?>
			},
			success: function(response) {
				response = JSON.parse(response);
				if (response.code == 200) {
					console.log(response);
					window.location.reload()
				} else if (response.code == 400) {
					console.log(response.error);

				} else {
					console.log(response.code);
				}
			}
		});
	}
	//DELETE
	function deleteRecord(record) {
		$.ajax({
			'url': "endpoints/consultant/consultantDelete.php",
			'type': "POST",
			'data': {
				<?= $ajaxVar[0] ?>: record,
			},
			success: function(response) {
				response = JSON.parse(response);
				if (response.code == 200) {
					console.log(response.code);
					alert("User successfully deleted!");
				} else if (response.code == 400) {
					console.log(response.error);

				} else {
					console.log(response.code);
				}
			}
		});
	}

	function modalAddUser() {
		$('#modalAddUser').modal('show');
	}
</script>