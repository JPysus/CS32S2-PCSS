<?php 
	$servername = "localhost";
// 	$username = "root";
// 	$password = "";
// 	$database = "pcss";
	$username = "id18436203_root";
	$password = "2c^vIWD-yh~e?t3&";
	$database = "id18436203_pcss";
	// Create connection
	$conn = new mysqli($servername, $username, $password, $database);

?>