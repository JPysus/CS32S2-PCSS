<style>
  .passExpirationButton {
    background: #333333d4;
    color: white;
    font-weight: bold;
    padding: 4px 8px;
    font-size: 13px;
    border-radius: 4px;
  }
  .passExpirationButton:hover{
    color:#ffd251;
  }
</style>

<nav id="navbar_top" class="navbar navbar-expand-lg bg-light" style="padding-top: inherit;padding-bottom: inherit;">
  <div class="container-fluid content-container" style="justify-content: space-between;align-items: baseline;">
    <div class="navbar" id="main_nav">
      <ul class="navbar-nav mt-3">
        <li class="nav-item">  
          </a>
          <a class="brand mt-3" href="#">
            <img src="assets/img/umbrella-icon-blue.png" alt="" width="45" height="45" class="d-inline-block align-text-top">
            Umbrella Corp
          </a>
        </li>
      </ul>

    </div> <!-- navbar-collapse.// -->
    <div style="text-align: center; display:<?php echo ($_COOKIE['passExpiration'] > 20) ? 'inherit':'none'; ?>;">
      <a class="passwordModal" href="#">
        <i class="fa-solid fa-circle-exclamation fa-2x" style="color: <?php echo ($_COOKIE['passExpiration'] >= 30) ? 'red':'orange'; ?>">
          </i>
      </a>
      <a class="passExpirationButton passwordModal" href="#">
        This account's password is about to expire.
      </a>
    </div>
    <div class="d-flex dropdown mt-2">
      <button class="btn dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
        <i class="fas fa-user"></i>
        <p class="text-capitalize d-inline text-light"><?php echo $_COOKIE["name"]; ?></p>
      </button>
      <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
        <li><a class="dropdown-item" href="user-list.php">Account</a></li>
        <li><a class="dropdown-item" href="logout.php">Logout</a></li>
      </ul>
    </div>
  </div> <!-- container-fluid.// -->
</nav>

<?php include 'modal-change-password.php'; ?>
<script>
  <?php if($_COOKIE['passExpiration'] >= 30){?>
    $('.modal.fade.show').show().css("background","rgb(0 0 0 / 80%)");
  <?php };?>

  $(".passwordModal").click(function(){
    $('.modal.fade.show').show();
  });



</script>
