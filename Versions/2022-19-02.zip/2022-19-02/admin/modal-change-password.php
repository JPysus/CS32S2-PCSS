<style>
	.modal.fade.show{
	    background: rgb(0 0 0 / 58%);
	    opacity: inherit;
	}
	.passExpiration-header-info{
	    background: #333333;
	    color: white;
	    padding: 4px 8px;
	    font-size: 17px;
	    border-radius: 4px;
	}
</style>
<div class="modal fade show" data-bs-keyboard="true">
	<div class="modal-dialog modal-dialog-centered">
		<div class="modal-content">
			<form id="modal-change-password" method="POST">
				<div class="modal-header justify-content-center">
					<i class="fa-solid fa-circle-exclamation fa-2x" style="color: <?php echo ($_COOKIE['passExpiration'] >= 30) ? 'red':'orange'; ?>">
					</i>
					<h1 class="caption-body fw-bold mt-3">Password Expiration</h1>

					<?php if($_COOKIE['passExpiration'] >= 30){?>
						<p class="passExpiration-header-info">This account is limited until new password is created</p>
					<?php }
						else{
					;?>
						<p class="passExpiration-header-info">This account will soon be limited until new password is created</p>
					<?php };?>
				</div>
				<div class="modal-body">
					<div class="container">
						<!-- <h4 class="mb-3 fw-bold  text-center">Login to your account</h4> -->
						<!-- div for error input-->
						<label for="password" class="form-label">Password</label>
						<div class="input-group flex-nowrap mb-3">
							<input type="password" class="form-control" placeholder="Password" id="passwordNew" name="password" value="" required>
							<label class="input-group-text" id="addon-wrapping" for="password"><i class="fas fa-lock fa-1x p-2"></i></label>
						</div>
					</div>
				</div>
				<div class="modal-footer justify-content-between mx-3 my-2">
					<a style="width: 50%; font-size: 12px">You will be logged out after inputting the password</a>
					<button type="submit" class="btn btnSquare" id="loginBtn" name="login">Login</button>
				</div>
			</form>
		</div>
	</div>
	<script>
	//onsubmit function
	$("#modal-change-password").bind('submit', function(e){
		expiringPasswordUpdate($("#passwordNew").val());
		oldPasswordInsert($("#passwordNew").val());
		return false;
		preventDefault();
	});

	//UPDATE
	function expiringPasswordUpdate(e) {
		$.ajax({
			'url': "endpoints/consultant/consultantUpdate.php",
			'type': "POST",
			'data': {
				consultant_id: <?php echo $_COOKIE['id'];?>,
				password: e,
			},
			success: function(response) {
				response = JSON.parse(response);
				if (response.code == 200) {

				} else if (response.code == 400) {
					console.log(response.error);

				} else {
					console.log(response.code);
				}
			}
		});
	}
	//insert
	function oldPasswordInsert(e) {
		$.ajax({
			'url': "endpoints/consultant/consultantPasswordOld.php",
			'type': "POST",
			'data': {
				consultant_id: <?php echo $_COOKIE['id'];?>,
				password: e,
			},
			success: function(response) {
				response = JSON.parse(response);
				if (response.code == 200) {
					window.location.replace("logout.php");
				} else if (response.code == 400) {
					console.log(response.error);

				} else {
					console.log(response.code);
				}
			}
		});
	}
	
	</script>
	<script>
		const pattern = /(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*\W)/;
		const dictionary = "assets/json/dictionary.json";
		var dicjson;
		$.getJSON(dictionary, function(result){
			dicjson = result;
		});
		const errMsg = [
			"Needs at least: 1 Upper Case, 1 Lower Case, 1 Special Char., 1 digit",
			"Password needs to be 10 characters or longer",
			"Word Detected: ",
			"Password Can't Contain Name of the User",
			"Password Can't Contain any of the 6 Previous Passwords"
			];
		const passwordPolicy = "Password does not conform to the Password Policy.";
		const errMsg2Len = errMsg[2].length;

		$("#passwordNew").on("input",function(){
			$(this).css("border","3px solid #AAFF00");
		    var password = $(this).val(),
		    	name = "<?php echo $_COOKIE['name'];?>".split(" ");
			var errIndex = -1;
		    console.log(" ");
		    $.post("endpoints/consultant/consultantPasswordOld.php", {consultant_id: <?php echo $_COOKIE['id']?>})
		    	.done(function(data){

					data = JSON.parse(data);
					for(var i = 0; i < data.length; i++){
						if(data[i]["password_old"] == password){
							errIndex=4;
							console.log(errMsg[errIndex]);
							$("#passwordNew").get(0).setCustomValidity(passwordPolicy);
							$("#passwordNew").css("border","2px solid red");
							break
						}
					}

					if(errIndex<0){	
						//checks if the password is 10 letters or more
						if(!pattern.test(password)){
							errIndex=0;
						}

					    //checks if password is against the regex
						else if(password.length < 10){
							errIndex=1;
						}	

						//checks if password is in dictionary
						//3 letter words or less are okay
						else if(errIndex < 0){
							for (let i = 0; i < password.length; i++) {
						        for (let j = i; j <= password.length; j++){
									let word = password.substr(i, j - i);
									if(name.includes(word.toLowerCase())){
										errIndex = 3;
									}
						        	if(j - i < 3){
						        		continue;
						        	}
									if(dicjson.hasOwnProperty(word.toLowerCase())){
										if(word.length > 3){
											errMsg[2] = errMsg[2].substr(0,errMsg2Len)+word;
											errIndex = 2;
										}
									}
									if(errIndex >= 0)break;
								}
								if(errIndex >= 0)break;
						    }	
						}

						$("#passwordNew").get(0).setCustomValidity("");
						if(errIndex >= 0){
							console.log(errMsg[errIndex]);
							//this.setCustomValidity(errMsg[errIndex]);
							$("#passwordNew").get(0).setCustomValidity(passwordPolicy);
							$("#passwordNew").css("border","2px solid red");
						}
					}

	    	});

		});
	</script>
</div>

