# CS301-PCSS
Patient Consultation Scheduler System (PCSS) is a student project in CS301-Software Engineering.
The system aims to let public users to schedule their appointments with the doctor.
This project is for course compliance and is subject for checking by the instructor.
