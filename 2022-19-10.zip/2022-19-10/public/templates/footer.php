<link rel="stylesheet" type="text/css" href="assets/css/footer.css">

<footer>
	<div class=" mt-5">
		<div class="card-footer bg-white">
			<!--
			<div class="row mb-4">
				<div class="col-md-4 col-sm-4 col-xs-4">
					<div class="footer-text pull-left">
						<div class="d-flex">
							<h1 class="brand"> Umbrella Corporation </h1>
						</div>
						<p class="">You life is secured with us. Join us, let us build the future.</p>
						<div class="social mt-2 mb-3"> <i class="fa fa-facebook-official fa-lg"></i> <i class="fa fa-instagram fa-lg"></i> <i class="fa fa-twitter fa-lg"></i> <i class="fa fa-linkedin-square fa-lg"></i> <i class="fa fa-facebook"></i> </div>
					</div>
				</div>
				<div class="col-md-2 col-sm-2 col-xs-2"></div>
				<div class="col-md-2 col-sm-2 col-xs-2">
					<h5 class="heading">Services</h5>
					<ul class="footer-ul">
						<li>Student Talks</li>
						<li>Development</li>
						<li>Project</li>
						<li>Support</li>
					</ul>
				</div>
				<div class="col-md-2 col-sm-2 col-xs-2">
					<h5 class="heading">Industries</h5>
					<ul class="footer-ul">
						<li>Education</li>
						<li>Public Sector</li>
						<li>Home business</li>
					</ul>
				</div>
				<div class="col-md-2 col-sm-2 col-xs-2">
					<h5 class="heading">Company</h5>
					<ul class="footer-ul">
						<li>About Us</li>
						<li>Blog</li>
						<li>Contact</li>
						<li>Join Us</li>
					</ul>
				</div>
			</div>
			-->
			<div class="divider mb-4"> </div>
			<div class="row" style="font-size:10px;">
				<div class="col-md-6 col-sm-6 col-xs-6">
					<div class="pull-left">
						<p><i class="fa fa-copyright"></i> 2021 StudentDevelopers</p>
					</div>
				</div>
				<div class="col-md-6 col-sm-6 col-xs-6">
					<div class="pull-right mr-4 d-flex policy">
						<div>Terms of Use</div>
						<div>Privacy Policy</div>
						<div>Cookie Policy</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</footer>
