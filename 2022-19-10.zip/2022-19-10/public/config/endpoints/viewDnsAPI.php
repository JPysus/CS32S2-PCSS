<?php 

$apikey="&apikey=b81e5f15d8bb78375c37fc01926f865924b0fcb0";
$output = "&output=json";

$actionArray = ["reverseip", "ping"];
$actionIndex = $_GET['actionIndex'];

$webparams = ["host", "domain", "ip"];
$webparamIndex = -1;

switch($actionIndex){
    case 0:case 1:
        $webparamIndex = 0;
    break;
}


$param1 =  $webparams[$webparamIndex] . "=" . $_SERVER['HTTP_HOST'];
$url = "https://api.viewdns.info/" . $actionArray[$actionIndex] . "/?" . $param1 . $apikey . $output;
// reverseip
// /?host=199.59.148.10
// &apikey=yourapikey
// &output=output_type XML Response (output=xml)

// echo file_get_contents($url);

echo file_get_contents('test.json');
?>