<?php 
	//display
	include("../db.php");
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}
	else{
		$consultant_id = $_POST['consultant_id'];
		
		if(isset($_POST['password'])){
			$password = $_POST['password'];
			$date = date('Y-m-d', time());
			$sql = "
				INSERT INTO password_old (password_old_id, password_old, password_date_changed, consultant_id) VALUES (NULL,'$password','$date','$consultant_id')
			";
			if ($conn -> query($sql) === TRUE) {
				$response = ["code"=>200];
			}
			else{
				$error = "Error:" . $sql . "<br>" . $conn->error;
				$response = ["code"=>400, "error" => $error];
			}
			echo json_encode($response);
		}
		else{
			$sql = "SELECT password_old FROM password_old WHERE consultant_id = '$consultant_id' ORDER BY consultant_id DESC LIMIT 6";
			$result = $conn -> query($sql);
			if ($result->num_rows > 0) {
				echo json_encode($result->fetch_all(MYSQLI_ASSOC));
			}
			else{
				$error = "Error:" . $sql . "<br>" . $conn->error;
				$response = ["code"=>400, "error" =>$error];
				echo json_encode($response);
			}
		}
			
	}

?>