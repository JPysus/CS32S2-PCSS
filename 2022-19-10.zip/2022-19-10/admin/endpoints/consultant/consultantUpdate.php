<?php 
	//update
	include("../db.php");
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}
	else{
		$consultant_id= $_POST['consultant_id'];
		$date = date('Y-m-d', time());
		// $fname= $_POST['fname'];
		// $lname= $_POST['lname'];
		// $email=$_POST['email'];
// 		fname='$fname', 
// 		lname='$lname', 
// 		email='$email', 
		$password=$_POST['password'];
		if(isset($_POST['job'])&& ($_POST['job']!=""||$_POST['job']!=NULL)){
			$job=$_POST['job'];
			$sql = "UPDATE consultant SET password='$password', job='$job', password_date_created = '$date' WHERE consultant_id='$consultant_id'";
		}
		else
			$sql = "UPDATE consultant SET password='$password',  password_date_created = '$date' WHERE consultant_id='$consultant_id'";
		


		if ($conn -> query($sql) === TRUE) {
			$response = ["code"=>200];
		}
		else{
			$error = "Error:" . $sql . "<br>" . $conn->error;
			$response = ["code"=>400, "error" => $error];
		}
		echo json_encode($response);
	}

?>
